# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dpsa4fl_example']

package_data = \
{'': ['*']}

install_requires = \
['flwr @ ../flower-with-prio']

setup_kwargs = {
    'name': 'dpsa4fl-example',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Maxim Urschumzew',
    'author_email': 'u.maxim@live.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
